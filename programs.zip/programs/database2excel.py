import pymysql
from openpyxl import Workbook
import time
wb = Workbook()
ws = wb.active
host = 'localhost'
port = 3306
user = 'root'
password = 'india@123'   # your password
database ='capgemini'

with pymysql.connect(host=host,port=port,user=user,password=password,database=database) as db:
    print(db)
    query= "select * from realestate"
    db.execute(query)
    for record in db.fetchall():
        street = record[0]
        city = record[1]
        ws.append([street,city])
# creating file with today's timestamp    
filename =   time.strftime("%d_%b_%Y.xlsx")   
wb.save(filename)    