

# write all the numbers from 1 to 9 to file
with open("numbers.txt","w") as fw:
    for value in range(1,10):
        fw.write(str(value) + "\n")
