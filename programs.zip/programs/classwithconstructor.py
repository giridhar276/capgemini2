




class Employee :

    def __init__(self,name):
        #local variables
        self.name = name
        
    def displayName(self):
        print("Empname :",self.name)


emp1 = Employee("Rita")
emp1.displayName()


emp2 = Employee("Geeta")
emp2.displayName()
