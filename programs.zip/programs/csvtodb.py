# insert query
import pymysql

host = 'localhost'
port = 3306
user = 'root'
password = 'india@123'   # your password
database ='capgemini'

with pymysql.connect(host=host,port=port,user=user,password=password,database=database) as db:
    with open("realestate.csv") as fr:
        for line in fr:
            #removing white spaces
            line = line.strip()
            # converting string(line)----> list
            data = line.split(",")    
            # query structure
            query = "insert into realestate values('{}','{}')"
            #executing the query
            db.execute(query.format(data[0] ,data[1]))
            print(db.rowcount , "record inserted")
    

    