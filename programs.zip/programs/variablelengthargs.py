#keyword arguments
# If any object is prefixed with *
#    it is tuple

def display(*info):
    for val in info:
        print(val)

display(10,20,30,40,50,60,70)



# If any object is prefixed with **
#    it is dictionary
def displaydata(**data):
    for key,value in data.items():
        print(key,value)

displaydata(chap1= 10 ,chap2 = 20)
