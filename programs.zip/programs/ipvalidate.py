


ip = input("Enter any IP:")
data = ip.split(".")
data = list(map(int,data))
if len(data) == 4:
    if data[0] in range(1,256) and data[1] in range(0,256) and data[2] in range(0,256) and data[3] in range(0,256):
        print("Valid ip")
    else:
        print("Invalid ip")
else:
    print("invalid ip")