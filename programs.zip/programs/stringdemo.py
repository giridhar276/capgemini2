name = 'python programming'
print(name[0])   #p
print(name[-1])  #y
print(name[0:5]) # excluding 5th index
print(name[4:9]) # on pr
print(name[0:17:2]) #pto rgamn
print(name[:6])     #python
print(name[1:17:2]) #yhnpormi
print(name[:])      #everything
print(name[::])     #everything
print(name[-5:-1])  #mmin
print(name[::-1])   #gnimmargorp nohtyp
