# 1st method
name = input("Enter any string :")
print(name.swapcase())    


### 2nd method

if name.isupper():
    print(name.lower())
elif name.islower():
    print(name.upper())    
    
# password validation
password = input("Enter any password :")    
if len(password) in range(5,12) and ('@' in password or '$' in password)  and not password.isupper():
    print("Valid password")
else:
    print("INvalid password")    