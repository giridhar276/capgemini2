data = {"menu": {
  "id": "file",
  "value": "File",
  "popup": {
    "menuitem": [
      {"value": "New", "onclick": "CreateNewDoc()"},
      {"value": "Open", "onclick": "OpenDoc()"},
      {"value": "Close", "onclick": "CloseDoc()"}
    ]
  }
}}
  
for key,value in data.items():
    for subkey,subvalue in value.items():
        if subkey == "popup":
            for key,value in subvalue.items():
                for item in value:
                    print(item['value'])