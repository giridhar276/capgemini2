a,b = 10,20

if a < b :
    print("A is less than B")
    print("Inside if")
    print("Still inside if")
else:
    print("This is else part")
    print("B is less than A")
    print("Still inside else")

print()


name = "python"
if name.isupper():
    print("String is defined in upper")
else:
    print("String is defined in lower")
    
    
    
    