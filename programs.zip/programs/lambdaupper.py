
#example1
add = lambda x : x + 5
total = add(5)
print(total)


#example2
getupper = lambda x : x.upper()
output = getupper("python")
print(output)


#example3
getsum = lambda x,y : x+y
output =getsum(10,20)
print(output)
