# fixed arguments
def display(first,second):
    print(first,second)
display(10,20)
