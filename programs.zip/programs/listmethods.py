alist = [10,20,30,40,50,2,434,43,10]

print("10 is repeated for :", alist.count(10))
print("Index of 20 :", alist.index(20))

alist.append(43)
print("After appending :", alist)
alist.append(7)
alist.append(53543)
print("After appending :", alist)
alist.extend([43,54,756,43645])
print("After extending :", alist)
#alist.insert(where to insert,what to insert)
alist.insert(0,5)
alist.insert(6,600)
print("After inserting :", alist)
alist.pop()    # remove value at last index
alist.pop(0)  # remove value at index 0
alist.pop(4)  # remove value at index 4
print("pop operation :", alist)
alist.remove(30) # remove 30 directly
alist.sort()
print("After sorting :", alist)
alist.reverse()
print("After reversing :", alist)

