name = "python programming"
print(name.upper())
print(name.lower())
print(name.isupper())
print(name.islower())
print(name.center(30))
print(name.center(30,"*"))
print(name.count("p"))
print(name.count("u"))
aname ="  python  "
print(aname.strip()) # will remove space
bname = "I love {} and {}"
print(bname.format("spark","scala"))
print(bname.format("hadoop","python"))

alist = name.split(" ")
print("List is  :", alist)
print(name.replace("python","ruby"))
