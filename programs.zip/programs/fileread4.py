## display all the unique cities ###

import urllib.request

url = 'http://samplecsvs.s3.amazonaws.com/Sacramentorealestatetransactions.csv'

filename = url.split("/")[-1]

cityset = set()

# downloading the file
urllib.request.urlretrieve(url,filename)

# reading the file
with open(filename,"r") as fr:
    for line in fr:
        line = line.strip()
        data = line.split(",")
        city = data[1]
        cityset.add(city)
    #end of processing
    for city in cityset:
        print(city)
