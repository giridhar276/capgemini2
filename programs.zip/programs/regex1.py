

with open("languages.txt","r") as fr:
    for line in fr:
        line = line.strip()
        print(line)
