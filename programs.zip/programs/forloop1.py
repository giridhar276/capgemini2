## 1 to 10
for val in range(1,10):
    print(val)
    
for val in range(10,1,-1):
    print(val)
    
# even numbers
for val in range(2,10,2)    :
    print(val)
    
# odd numbers
for val in range(1,10,2)    :
    print(val)