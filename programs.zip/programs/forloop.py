# for with range()
for val in range(1,11):
    print(val)

# for with string
name = 'python'
for char in name:
    print(char)

# for with list
alist = [10,20,30,40]
for val in alist:
    print(val)


# for with tuple
atup = (10,"unix","oracle")
for val in atup:
    print(val)

# for with dictionary
book = {"chap1":10 ,"chap2":20 ,"chap3":30}
for key,value in book.items():
    print(key,value)

#for with set
aset = {10,10,10,10,10,20}
for val in aset:
    print(val)
