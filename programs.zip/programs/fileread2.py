

try:
    #reading line by line
    filename = input("Enter any filename :")
    with open(filename,"r") as fr:
        for line in fr:
            line = line.strip()
            print(line)
except FileNotFoundError as err :
    print("Error found")
    print("System error :", err)
