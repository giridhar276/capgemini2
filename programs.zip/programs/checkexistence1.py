'''
define a string as below

lang = "perl,unix,hadoop,scala,spark,ruby,go"

write a program to check whether 'python' is existing in the string or not.'
'''

lang = "perl,unix,hadoop,scala,spark,ruby,go"

if "python" in lang:
    print("exists")
else:
    print("Doesnt'exist")
