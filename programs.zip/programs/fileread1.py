#reading line by line
with open("numbers.txt","r") as fr:
    for line in fr:
        line = line.strip()
        print(line)

print("--------------------------------")
# reading the complete file in string format
with open("numbers.txt","r") as fr:
    print(fr.read())

print("--------------------------------")

# reading the complete file in list format
with open("numbers.txt","r") as fr:
    print(fr.readlines())

#####################
### using csv library
#####################
import csv
with open("numbers.txt","r") as fr:
    ## converting to csv object
    reader = csv.reader(fr)
    for line in reader:
        print(line)
