
class Employee :
    def displayName(self,name):
        # local assignment
        self.name = name
        print("Empname :",self.name)


emp1 = Employee()
emp1.displayName("Rita")


emp2 = Employee()
emp2.displayName("Geeta")