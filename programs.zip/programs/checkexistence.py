'''
define a string as below

lang = "perl,unix,hadoop,scala,spark,ruby,go"

write a program to check whether 'python' is existing in the string or not.
'''


lang = "perl,unix,hadoop,scala,spark,ruby,go"

if 'python' in lang:
    print("String exists")
else:
    print("String doesn't exist")
    
    
alist =[10,20,30,40]
if 10 in alist:
    print("exists")
else:
    print("doesn't exist")