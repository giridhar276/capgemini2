'''
192.168.0.1'
..
..
192.168.0.10'
'''

fixed = "192.168.0."
for val in range(1,10):
    ip = fixed + str(val)
    print(ip)

'''
192.168..0.1

...
192.168..0.10
192.168..1.1

...
192.168..1.10
'''
fixed = '192.168.'
for val in range(0,2):
    ip = fixed + str(val)
    for val in range(1,10):
        finalip = ip + '.' +  str(val)
        print(finalip)










