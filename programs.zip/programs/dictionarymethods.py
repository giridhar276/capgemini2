  adict = {"chap1":10 ,"chap2":20}
print(adict)
#adding key-value to dictionary
adict["chap3"] = 30
adict["chap4"] = 40
print("dictionary elements are :", adict)
## accessing value
print(adict["chap1"])  #10
### ONLY keys
print(adict.keys())
### ONLY values
print(adict.values())
##   display in [(key,value),(key,value)]
print(adict.items())
#print(adict["chap5"])
print(adict.get("chap1"))
print(adict.get("chap5")) #if not existing.. return None
adict.pop("chap1")  # will remove chap1:10 
print("after pop :", adict)
adict.popitem()     # will remove random key:value pair
print("After popitem :", adict)


print(adict)
bdict = {"chap11":110 ,"chap12":120}
adict.update(bdict)  # all the key:values of bdict will
                     #  b updating to adict
print("After updating :", adict)
## combining both the dictionaries to final dictionary
final = {**adict,**bdict}
print(final)



