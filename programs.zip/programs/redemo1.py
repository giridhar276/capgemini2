# method1
name = "python programming"
if 'python' in name:
    print("Exists")
    
# method2  -- preferred method
import re
name = "python programming"
if re.search("python",name):
    print("Exists")
    
# re.sub ----------> substitute
name = "python programming"
name = re.sub("python","ruby",name)    
print("After replacing :", name)
    
# re.finall()
line  = "The rain in Spain"
x = re.findall("ai", line)
print(x)
    