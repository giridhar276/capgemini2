
 
alist = [10,20,30,40]

print(alist[0])

alist[0] =1000

print("After replacing :", alist)


# tuple
atup = (10,20,30,40)
#atup[0] = "unix"
print("After replacing :", atup)
 