aset = {10,20,30,20,10,10,20,30}
bset = {30,40,50}
## adding new value to aset
aset.add(50)
### performing union operation
print(aset | bset)    
## OR
print(aset.union(bset))
# intersection
print(aset & bset)
print(aset.intersection(bset))
## difference
print(aset - bset)
print(aset.difference(bset))
# to check issubset
print(aset.issubset(bset))