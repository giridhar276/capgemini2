##################   METHOD1 ####################
fobj = open("clients.txt","w")
# writing data to file
fobj.write("python programming\n")
fobj.write("unix shell programming\n")
# closing the file
fobj.close()

####################### METHOD2 ################
############ USING CONTEXT MANAGER ############
## file will be closed automatically ##########
with open("clients.txt","w") as fw:
    fw.write("unix shell scripting\n")
    fw.write("java programming\n")