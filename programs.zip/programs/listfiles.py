# listing all the files from current directory
import os
for file in os.listdir():
    print(file)
    
# listing files from C:
import os
for file in os.listdir("C:\\"):
    print(file)
    
# displaying current login name
import os
print(os.getlogin())    

# for the current working directory
print(os.getcwd())

# display the filesize
getsize = os.path.getsize('tuplemethods.py')
print(getsize , "bytes")

# display current date and time
import datetime
print(datetime.datetime.now())   # current time stamp

# using time
import time
print(time.strftime("%d %b %Y"))










