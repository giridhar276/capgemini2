import urllib.request

url = 'http://samplecsvs.s3.amazonaws.com/Sacramentorealestatetransactions.csv'

filename = url.split("/")[-1]

print(filename)
# downloading the file
urllib.request.urlretrieve(url,filename)

# reading the file
with open(filename,"r") as fr:
    for line in fr:
        line = line.strip()
        data = line.split(",")
        print("Street :", data[0])
        print("City   :",data[1])
        print("----------")